package com.example.UTS

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
